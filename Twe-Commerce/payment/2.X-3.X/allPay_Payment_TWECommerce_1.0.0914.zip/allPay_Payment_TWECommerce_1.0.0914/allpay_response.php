<?php
include( 'includes/application_top.php');
$pay = !empty($_REQUEST['pay']) ? trim($_REQUEST['pay']) : '';
if ($pay == "") {
    die('access denid');
}
$plugin_file = 'includes/modules/payment/' . $pay . '.php';
if (file_exists($plugin_file)) {
    include_once($plugin_file);
    $payment = new $pay();
    $ans = $payment->respond();
    $msg = $ans;
} else {
    $msg = '檔案不存在';
}
echo $msg;
?>


