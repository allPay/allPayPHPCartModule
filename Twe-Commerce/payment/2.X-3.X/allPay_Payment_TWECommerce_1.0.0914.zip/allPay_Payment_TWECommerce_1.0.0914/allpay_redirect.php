<?php
include( 'includes/application_top.php');
//歐付寶 Allpay AIO串接模組轉跳程式
if (!isset($_REQUEST['ChoosePayment']) || !isset($_REQUEST['ClientBackURL']) || !isset($_REQUEST['ItemName']) || !isset($_REQUEST['MerchantID']) 
        || !isset($_REQUEST['MerchantTradeDate']) || !isset($_REQUEST['MerchantTradeNo']) || !isset($_REQUEST['PaymentType']) || !isset($_REQUEST['ReturnURL'])
        || !isset($_REQUEST['TotalAmount']) || !isset($_REQUEST['TradeDesc']) || !isset($_REQUEST['CheckMacValue'])) {
    die("access denie");
}
echo "頁面轉跳中，請稍候";
$input_array = array(
    'ChoosePayment' => $_REQUEST['ChoosePayment'],
    'ClientBackURL' => $_REQUEST['ClientBackURL'],
    'ItemName' => $_REQUEST['ItemName'],
    'MerchantID' => $_REQUEST['MerchantID'],
    'MerchantTradeDate' => $_REQUEST['MerchantTradeDate'],
    'MerchantTradeNo' => $_REQUEST['MerchantTradeNo'],
    'PaymentType' => $_REQUEST['PaymentType'],
    'ReturnURL' => $_REQUEST['ReturnURL'],
    'TotalAmount' => $_REQUEST['TotalAmount'],
    'TradeDesc' => $_REQUEST['TradeDesc'],
    'CheckMacValue' => $_REQUEST['CheckMacValue']
);
if(isset($_REQUEST['CreditInstallment'])){
    $input_array['CreditInstallment'] = $_REQUEST['CreditInstallment'];
}
if($_REQUEST['ChoosePayment'] == 'Alipay'){
    $input_array['AlipayItemName'] = $_REQUEST['AlipayItemName'];
    $input_array['AlipayItemPrice'] = $_REQUEST['AlipayItemPrice'];
    $input_array['AlipayItemCounts'] = $_REQUEST['AlipayItemCounts'];
    $input_array['Email'] = $_REQUEST['Email'];
    $input_array['PhoneNo'] = $_REQUEST['PhoneNo'];
    $input_array['UserName'] = $_REQUEST['UserName'];
}
//$allpay_gateway = "http://payment-stage.allpay.com.tw/Cashier/AioCheckOut";
$allpay_gateway = "https://payment.allpay.com.tw/Cashier/AioCheckOut";

$output_str = "<form method='post' action='$allpay_gateway'>";
foreach ($input_array as $name => $value) {
    $output_str .= "<input type='hidden' name='$name' value='$value'>";
}
//$output_str .= "<input type='submit'>";
$output_str .= "</form>";
//====自動送出form====

$output_str .= '<script type="text/javascript" language="javascript">
function do_submit() { document.forms[0].submit(); }
	do_submit();
</script>';
echo $output_str;
?>
