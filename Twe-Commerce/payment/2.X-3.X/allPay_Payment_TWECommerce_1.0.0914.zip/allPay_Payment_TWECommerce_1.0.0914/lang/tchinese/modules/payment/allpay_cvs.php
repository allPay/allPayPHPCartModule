<?php
/*

   -----------------------------------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(german.php,v 1.119 2003/05/19); www.oscommerce.com 
   (c) 2003	 nextcommerce (german.php,v 1.25 2003/08/25); www.nextcommerce.org
   (c) 2003	 xtcommerce  www.xt-commerce.com   
   Released under the GNU General Public License 
*/

  define('MODULE_PAYMENT_ALLPAY_CVS_TEXT_TITLE', '歐付寶 AIO CVS超商代碼收款模組');
  define('MODULE_PAYMENT_ALLPAY_CVS_TEXT_DESCRIPTION', '歐付寶 AIO CVS超商代碼收款模組<br><a href=http://www.allpay.com.tw target=_blank>http://www.allpay.com.tw</a>');
  define('MODULE_PAYMENT_ALLPAY_CVS_STATUS_TITLE','歐付寶 AIO CVS超商代碼收款模組啟動');
  define('MODULE_PAYMENT_ALLPAY_CVS_STATUS_DESC','歐付寶 AIO CVS超商代碼收款模組是否啟動?');

  define('MODULE_PAYMENT_ALLPAY_CVS_SORT_ORDER_TITLE','歐付寶 AIO CVS超商代碼收款模組 顯示順序');
  define('MODULE_PAYMENT_ALLPAY_CVS_SORT_ORDER_DESC','顯示順序，數字越小順序在前');
    define('MODULE_PAYMENT_ALLPAY_CVS_ORDER_STATUS_ID_TITLE','付款結帳完成時預設訂單狀態');
  define('MODULE_PAYMENT_ALLPAY_CVS_ORDER_STATUS_ID_DESC','使用 歐付寶 AIO CVS超商代碼 付款結帳完成時,TWE 內訂單的預設狀態');

  define('MODULE_PAYMENT_ALLPAY_CVS_ORDER_STATUS_ID_TITLE','付款結帳完成時預設訂單狀態');
  define('MODULE_PAYMENT_ALLPAY_CVS_ORDER_STATUS_ID_DESC','使用 歐付寶 AIO CVS超商代碼收款模組結帳完成時,TWE 內訂單的預設狀態');
  define('MODULE_PAYMENT_ALLPAY_CVS_MID_TITLE','歐付寶(Allpay) 商家編號');
  define('MODULE_PAYMENT_ALLPAY_CVS_MID_DESC','設定 歐付寶(Allpay) 商店編號,<br>如果還沒申請請電 02-26550115 歐付寶客服部<a target=_blank href=http://www.allpay.com.tw>http://www.allpay.com.tw</a>');
  define('MODULE_PAYMENT_ALLPAY_CVS_TEXT_CONFIRMATION','本網站採用(<a href="http://www.allpay.com.tw" target="_BLANK"><font color=green>歐付寶(Allpay)</font> 歐付寶 AIO CVS超商代碼收款模組</a>)</font>。在您按下"確認訂單"鈕後,網頁將導向本公司專屬的 SSL 加密網頁中進行，請放心使用！</span>');
  define('MODULE_PAYMENT_ALLPAY_CVS_HASHKEY_TITLE','歐付寶(Allpay) 商店Hash_Key');
  define('MODULE_PAYMENT_ALLPAY_CVS_HASHKEY_DESC','設定歐付寶(Allpay)金流<b>[商店Hash_Key]</b>,<br>可檢驗資料正確與合法性');
  define('MODULE_PAYMENT_ALLPAY_CVS_HASHIV_TITLE','歐付寶(Allpay) 商店Hash_IV');
  define('MODULE_PAYMENT_ALLPAY_CVS_HASHIV_DESC','設定歐付寶(Allpay)金流<b>[商店Hash_IV]</b>,<br>可檢驗資料正確與合法性');  
  define('MODULE_PAYMENT_ALLPAY_CVS_ALLOWED_TITLE','歐付寶(Allpay) 線上金流 轉帳國家'); 
  define('MODULE_PAYMENT_ALLPAY_CVS_ALLOWED_DESC','請留空白');    
  define('MODULE_PAYMENT_ALLPAY_CVS_TEXT_ERROR_1', '中國信託信用卡分期付款結帳，每筆結帳金額不得低於新台幣300元');
  define('MODULE_PAYMENT_ALLPAY_CVS_TEXT_ERROR_2', '線上付款授權失敗，請確認所輸入相關資訊正確無誤');
  define('MODULE_PAYMENT_ALLPAY_CVS_TEXT_ERROR_3', '授權回傳驗證金額失敗');
  define('MODULE_PAYMENT_ALLPAY_CVS_TEXT_ERROR', '歐付寶(Allpay) 線上金流付款機制，錯誤訊息!');
?>
