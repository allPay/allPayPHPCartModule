<?php

// allpay AIO barcode付款模組 by Roger
// 因為TWE內建的導向付款頁面功能會多吐出x=? y=?兩項不必要的參數
// 故多寫一個跳板頁面allpay_redirect.php再轉拋出去allpay的付款gateway
// TWE不支援幕後觸發，故也只能用另一支程式allpay_response.php來回應
// 採用先完成訂單方式再做導向付款(寫在after_process)
class allpay_barcode {

    var $code, $title, $description, $enabled;

// class constructor
    function allpay_barcode() {
        global $order;

        $this->code = 'allpay_barcode';
        $this->title = MODULE_PAYMENT_ALLPAY_BARCODE_TEXT_TITLE;
        $this->description = MODULE_PAYMENT_ALLPAY_BARCODE_TEXT_DESCRIPTION;
        $this->sort_order = MODULE_PAYMENT_ALLPAY_BARCODE_SORT_ORDER;
        $this->enabled = ((MODULE_PAYMENT_ALLPAY_BARCODE_STATUS == 'True') ? true : false);

        if ((int) MODULE_PAYMENT_ALLPAY_BARCODE_ORDER_STATUS_ID > 0) {
            $this->order_status = MODULE_PAYMENT_ALLPAY_BARCODE_ORDER_STATUS_ID;
        }

        if (is_object($order)) {
            $this->update_status();
        }
        //$this->form_action_url = "allpay_redirect.php";
    }

    function payment_error($url_payment_error) {
        twe_redirect(twe_href_link(FILENAME_CHECKOUT_PAYMENT, $url_payment_error, 'SSL', true, false));
    }

// class methods
    function update_status() {
        global $order, $db;

        if (($this->enabled == true) && ((int) MODULE_PAYMENT_ALLPAY_BARCODE_ZONE > 0)) {
            $check_flag = false;
            $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_ALLPAY_BARCODE_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
            while (!$check->EOF) {
                if ($check->fields['zone_id'] < 1) {
                    $check_flag = true;
                    break;
                } elseif ($check->fields['zone_id'] == $order->delivery['zone_id']) {
                    $check_flag = true;
                    break;
                }
                $check->MoveNext();
            }

            if ($check_flag == false) {
                $this->enabled = false;
            }
        }
    }

    function javascript_validation() {
        return false;
    }

    function selection() {
        $selection = array('id' => $this->code,
            'module' => $this->title);
        return $selection;
    }

    function pre_confirmation_check() {
        return false;
    }

    function confirmation() {
        return array('title' => MODULE_PAYMENT_ALLPAY_BARCODE_TEXT_CONFIRMATION);
    }

    function process_button() {
        /*    global $order, $SID, $db;



          $process_button_string = "";
          foreach ($input_array as $param => $value) {
          $process_button_string .= twe_draw_hidden_field($param, $value);
          } */

        return true;
    }

    function before_process() {
        return false;
    }

    function get_result($gateway, $str) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $gateway);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
        $rs = curl_exec($ch);
        curl_close($ch);
        return $rs;
    }

    function get_error() {
        switch ($_REQUEST['error']) {
            case 1 : $error = MODULE_PAYMENT_ALLPAY_BARCODE_TEXT_ERROR_1;
                break;
            case 2 : $error = MODULE_PAYMENT_ALLPAY_BARCODE_TEXT_ERROR_2;
                break;
            case 3 : $error = MODULE_PAYMENT_ALLPAY_BARCODE_TEXT_ERROR_3;
                break;
        }
        $error = array('title' => MODULE_PAYMENT_ALLPAY_BARCODE_TEXT_ERROR,
            'error' => $error);
        return $error;
    }

    function after_process() {
        global $order, $insert_id, $db;
        $oid = date('Ymdhis');
        $db->Execute("update " . TABLE_ORDERS . " set cc_number ='" . $oid . "' where orders_id='" . (int) $insert_id . "'");
        $mid = MODULE_PAYMENT_ALLPAY_BARCODE_MID;
        $hash_iv = MODULE_PAYMENT_ALLPAY_BARCODE_HASHIV;
        $hash_key = MODULE_PAYMENT_ALLPAY_BARCODE_HASHKEY;
        $price = str_replace("NT$", "", $order->info['total']);
        $price = str_replace(",", "", $price);
        $product = "internet product";
        $desc = "Allpay_TWE_Module";
        $date = date('Y/m/d H:i:s');
        $webaddr = ( ENABLE_SSL ? 'https://' : 'http://' ) . $_SERVER['SERVER_NAME'] . substr($_SERVER['PHP_SELF'], 0, strrpos($_SERVER['PHP_SELF'], "/") + 1);
        $roturl = $webaddr . "allpay_response.php?pay=allpay_barcode";

        $input_array = array(
            'ChoosePayment' => 'BARCODE',
            'ClientBackURL' => twe_href_link(FILENAME_DEFAULT, '', 'SSL'), //前台
            'ItemName' => $product,
            'MerchantID' => $mid,
            'MerchantTradeDate' => $date,
            'MerchantTradeNo' => $oid,
            'PaymentType' => 'aio',
            'ReturnURL' => $roturl,
            'TotalAmount' => round($price),
            'TradeDesc' => $desc
        );

        ksort($input_array);
        $checkvalue = "HashKey=" . $hash_key . "&" . urldecode(http_build_query($input_array)) . "&HashIV=" . $hash_iv;
        $checkvalue = urlencode($checkvalue);
        $checkvalue = strtolower($checkvalue);
        $checkvalue = md5($checkvalue);
        //$input_array['CheckMacValue'] = $checkvalue;

        $url = "allpay_redirect.php?CheckMacValue=" . $checkvalue;
        foreach ($input_array as $name => $value) {
            $url .= "&$name=$value";
        }
        $_SESSION['cart']->reset(true);

// unregister session variables used during checkout
        unset($_SESSION['sendto']);
        unset($_SESSION['billto']);
        unset($_SESSION['shipping']);
        unset($_SESSION['payment']);
        unset($_SESSION['comments']);
        unset($_SESSION['last_order']);
        twe_redirect($url);
        return FALSE;
    }

    function output_error() {
        return false;
    }

    function respond() {
        global $db;
        $timestamp = time();
        $iv = MODULE_PAYMENT_ALLPAY_BARCODE_HASHIV;
        $key = MODULE_PAYMENT_ALLPAY_BARCODE_HASHKEY;
        $allpay_order_id = $_REQUEST['MerchantTradeNo'];
        $mer_id = MODULE_PAYMENT_ALLPAY_BARCODE_MID;
        $payment_type = $_REQUEST['Payment_Type'];

        $input_array = array(
            "MerchantID" => $mer_id,
            "MerchantTradeNo" => $allpay_order_id,
            "TimeStamp" => $timestamp
        );
        $order_id_array = $db->Execute("select orders_id from orders where cc_number='" . $allpay_order_id . "'");
        $order_id = $order_id_array->fields['orders_id'];
        ksort($input_array);
        $checkvalue = "HashKey=$key&" . urldecode(http_build_query($input_array)) . "&HashIV=$iv";
        $checkvalue = strtolower(urlencode($checkvalue));
        $checkvalue = md5($checkvalue);
        $input_array["CheckMacValue"] = $checkvalue;
        $sned_string = http_build_query($input_array);

        $gateway = "https://payment.allpay.com.tw/Cashier/QueryTradeInfo";
        //$gateway = "http://payment-stage.allpay.com.tw/Cashier/QueryTradeInfo";

        $result = $this->get_result($gateway, $sned_string);

        parse_str($result, $res);
//判斷資料結果
//--------------單元測試--------------
        //$res["TradeStatus"] = '1';
//-------------單元測試--------------
        if ($_REQUEST['RtnCode'] == '1' && $res["TradeStatus"] == "1" && $res["TradeAmt"] == $_REQUEST['TradeAmt']) {
            $order_id_str = "allpay訂單編號:" . $allpay_order_id;
            $orders_status = MODULE_PAYMENT_ALLPAY_BARCODE_ORDER_STATUS_ID;
            $db->Execute("insert into " . TABLE_ORDERS_STATUS_HISTORY . " (orders_id, orders_status_id, date_added, customer_notified, comments) values ('" . $order_id . "', '" . $orders_status . "', now(), '', '" . $order_id_str . "')");
            $db->Execute("update " . TABLE_ORDERS . " set cc_type = '" . $payment_type . "',orders_status='" . $orders_status . "' ,last_modified = now() where cc_number = '" . $allpay_order_id . "'");
            return "1|OK";
        } else {
            return "0|fail";
        }
    }

    function check() {
        global $db;
        if (!isset($this->_check)) {
            $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_ALLPAY_BARCODE_STATUS'");
            $this->_check = $check_query->RecordCount();
        }
        return $this->_check;
    }

    function install() {
        global $db;
        //啟用狀態
        $db->Execute("insert into " . TABLE_CONFIGURATION .
                " (configuration_key, configuration_value, configuration_group_id, sort_order, set_function, date_added) 
                    values ( 'MODULE_PAYMENT_ALLPAY_BARCODE_STATUS', 'True', '6', '18', 'twe_cfg_select_option(array(\'True\', \'False\'), ', now())");
        //排序
        $db->Execute("insert into " . TABLE_CONFIGURATION .
                " (configuration_key, configuration_value, configuration_group_id, sort_order, date_added) 
                    values ('MODULE_PAYMENT_ALLPAY_BARCODE_SORT_ORDER', '0', '6', '18', now())");
        //商店代號
        $db->Execute("insert into " . TABLE_CONFIGURATION .
                " (configuration_key, configuration_value, configuration_group_id, sort_order, date_added) 
                    values ( 'MODULE_PAYMENT_ALLPAY_BARCODE_MID', '', '6', '18', now())");
        //HASHKEY
        $db->Execute("insert into " . TABLE_CONFIGURATION .
                " (configuration_key, configuration_value, configuration_group_id, sort_order, date_added) 
                    values ('MODULE_PAYMENT_ALLPAY_BARCODE_HASHKEY', '', '6', '18', now())");
        //HASHIV
        $db->Execute("insert into " . TABLE_CONFIGURATION .
                " (configuration_key, configuration_value, configuration_group_id, sort_order, date_added) 
                    values ('MODULE_PAYMENT_ALLPAY_BARCODE_HASHIV', '', '6', '18', now())");
        $db->Execute("insert into " . TABLE_CONFIGURATION .
                " (configuration_key, configuration_value, configuration_group_id, sort_order, date_added) 
                    values ('MODULE_PAYMENT_ALLPAY_BARCODE_ALLOWED', '', '6', '0', now())");
        $db->Execute("insert into " . TABLE_CONFIGURATION .
                " (configuration_key, configuration_value, configuration_group_id, sort_order, set_function, use_function, date_added) 
                    values ('MODULE_PAYMENT_ALLPAY_BARCODE_ORDER_STATUS_ID', '0', '6', '18', 'twe_cfg_pull_down_order_statuses(', 'twe_get_order_status_name', now())");
    }

    function remove() {
        global $db;
        $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
        return array(
            'MODULE_PAYMENT_ALLPAY_BARCODE_STATUS',
            'MODULE_PAYMENT_ALLPAY_BARCODE_MID',
            'MODULE_PAYMENT_ALLPAY_BARCODE_ALLOWED',
            'MODULE_PAYMENT_ALLPAY_BARCODE_HASHKEY',
            'MODULE_PAYMENT_ALLPAY_BARCODE_ALLOWED',
            'MODULE_PAYMENT_ALLPAY_BARCODE_ORDER_STATUS_ID',
			'MODULE_PAYMENT_ALLPAY_BARCODE_SORT_ORDER',
            'MODULE_PAYMENT_ALLPAY_BARCODE_HASHIV');
    }

}

?>