<?php


global $_LANG;

$_LANG['allpay_cvs'] = '<font color=blue>欧付宝 ALLPAY 超商代码</font>';
$_LANG['allpay_cvs_desc'] = ' 欧付宝 ALLPAY - <font color=red> 超商代码支付</font>';
$_LANG['allpay_cvs_test_mode'] = '测试模式？';
$_LANG['allpay_cvs_test_mode_range']['Yes'] = '是';
$_LANG['allpay_cvs_test_mode_range']['No'] = '否';
$_LANG['allpay_cvs_account'] = '商店代号(必填)';
$_LANG['allpay_cvs_iv'] = '欧付宝 ALLPAY IV(必填)';
$_LANG['allpay_cvs_key'] = '欧付宝 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '欧付宝 ALLPAY 超商代码支付取号';

$_LANG['text_goods'] = '网路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paying'] = '<b>付款中</b> %s\n付款方式: %s\n付款时间: %s\n缴费代码: %s\n付款截止日: %s\n条码第一段号码: %s\n条码第二段号码: %s\n条码第三段号码: %s\n';
$_LANG['text_paid'] = '付款完成';
