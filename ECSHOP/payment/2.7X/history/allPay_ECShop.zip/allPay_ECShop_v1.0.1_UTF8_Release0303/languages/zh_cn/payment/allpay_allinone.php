<?php

global $_LANG;

$_LANG['allpay_allinone'] = '<font color=blue>欧付宝 ALLPAY 全功能</font>';
$_LANG['allpay_allinone_desc'] = ' 欧付宝 ALLPAY - <font color=red> 全功能支付</font>';
$_LANG['allpay_allinone_test_mode'] = '测试模式？';
$_LANG['allpay_allinone_test_mode_range']['Yes'] = '是';
$_LANG['allpay_allinone_test_mode_range']['No'] = '否';
$_LANG['allpay_allinone_account'] = '商店代号(必填)';
$_LANG['allpay_allinone_iv'] = '欧付宝 ALLPAY IV(必填)';
$_LANG['allpay_allinone_key'] = '欧付宝 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '欧付宝 ALLPAY 付款';

$_LANG['text_goods'] = '网路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paid'] = '付款完成';
