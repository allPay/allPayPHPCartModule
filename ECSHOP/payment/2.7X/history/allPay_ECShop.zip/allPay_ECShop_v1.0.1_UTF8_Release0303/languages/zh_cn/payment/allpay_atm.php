<?php


global $_LANG;

$_LANG['allpay_atm'] = '<font color=blue>欧付宝 ALLPAY ATM</font>';
$_LANG['allpay_atm_desc'] = ' 欧付宝 ALLPAY - <font color=red> ATM</font>';
$_LANG['allpay_atm_test_mode'] = '测试模式？';
$_LANG['allpay_atm_test_mode_range']['Yes'] = '是';
$_LANG['allpay_atm_test_mode_range']['No'] = '否';
$_LANG['allpay_atm_account'] = '商店代号(必填)';
$_LANG['allpay_atm_iv'] = '欧付宝 ALLPAY IV(必填)';
$_LANG['allpay_atm_key'] = '欧付宝 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '欧付宝 ALLPAY ATM付款';

$_LANG['text_goods'] = '网路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paying'] = '<b>付款中</b> %s\n付款方式: %s\n付款时间: %s\n银行代码: %s\n虚拟帐号: %s\n付款截止日: %s\n';
$_LANG['text_paid'] = '付款完成';
