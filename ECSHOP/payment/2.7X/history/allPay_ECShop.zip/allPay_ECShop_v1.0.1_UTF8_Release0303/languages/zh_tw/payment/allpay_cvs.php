<?php


global $_LANG;

$_LANG['allpay_cvs'] = '<font color=blue>歐付寶 ALLPAY 超商代碼</font>';
$_LANG['allpay_cvs_desc'] = ' 歐付寶 ALLPAY - <font color=red> 超商代碼支付</font>';
$_LANG['allpay_cvs_test_mode'] = '測試模式？';
$_LANG['allpay_cvs_test_mode_range']['Yes'] = '是';
$_LANG['allpay_cvs_test_mode_range']['No'] = '否';
$_LANG['allpay_cvs_account'] = '商店代號(必填)';
$_LANG['allpay_cvs_iv'] = '歐付寶 ALLPAY IV(必填)';
$_LANG['allpay_cvs_key'] = '歐付寶 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '歐付寶 ALLPAY 超商代碼支付取號';

$_LANG['text_goods'] = '網路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paying'] = '<b>付款中</b> %s\n付款方式: %s\n付款時間: %s\n繳費代碼: %s\n付款截止日: %s\n條碼第一段號碼: %s\n條碼第二段號碼: %s\n條碼第三段號碼: %s\n';
$_LANG['text_paid'] = '付款完成';
