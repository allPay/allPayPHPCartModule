<?php

global $_LANG;

$_LANG['allpay_card18'] = '<font color="blue">歐付寶 ALLPAY 信用卡 分18期</font>';
$_LANG['allpay_card18_desc'] = ' 歐付寶 ALLPAY - <font color="red"> 信用卡支付</font>';
$_LANG['allpay_card18_test_mode'] = '測試模式？';
$_LANG['allpay_card18_test_mode_range']['Yes'] = '是';
$_LANG['allpay_card18_test_mode_range']['No'] = '否';
$_LANG['allpay_card18_account'] = '商店代號(必填)';
$_LANG['allpay_card18_iv'] = '歐付寶 ALLPAY IV(必填)';
$_LANG['allpay_card18_key'] = '歐付寶 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '歐付寶 ALLPAY 信用卡(分18期)付款';

$_LANG['text_goods'] = '網路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paid'] = '付款完成';
