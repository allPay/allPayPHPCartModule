<?php
if (strpos($order_info['shipping_code'],"allpaylogistic.") !== false) {
	$CreateShippingOrder = $this->url->link('shipping/allpaylogistic/create_shipping_order&order_id='.$data['order_id'], 'token=' . $this->session->data['token'], 'SSL');
	$WindowOpenCmd = "window.open('" . $CreateShippingOrder . "','allPayLogistic',config='width=800,height=600,status=no,scrollbars=yes,toolbar=no,location=no,menubar=no');";
	$ShowCVSMap = $this->url->link('shipping/allpaylogistic/show_cvs_map_by_order&order_id='.$data['order_id'], 'token=' . $this->session->data['token'], 'SSL');
	$ShowMapCmd = "window.open('" . $ShowCVSMap . "','allPayLogistic',config='width=1024,height=600,status=no,scrollbars=yes,toolbar=no,location=no,menubar=no');";
	$allpaylogistic_query = $this->db->query("Select * from allpaylogistic_info where order_id=".$data['order_id']);
	if (!$allpaylogistic_query->num_rows) {
		if (isset($data['shipping_address_1'])) {
			$data['shipping_address_1'] .= "&nbsp;" . '<input type="button" id="allpaylogistic_store" class="btn btn-primary btn-xs" value="變更門市" onClick="javascript:' . $ShowMapCmd .'"/>';
		} else {
			$data['shipping_address'] .= "<br>" . '<input type="button" id="allpaylogistic_store" class="btn btn-primary btn-xs" value="變更門市" onClick="javascript:' . $ShowMapCmd .'"/>';
		}
		$data['shipping_method'] .= "&nbsp;" . '<input type="button" id="allpaylogistic" class="btn btn-primary btn-xs" value="建立物流訂單" onClick="javascript:' . $WindowOpenCmd .'"/>';
	}
}
?>