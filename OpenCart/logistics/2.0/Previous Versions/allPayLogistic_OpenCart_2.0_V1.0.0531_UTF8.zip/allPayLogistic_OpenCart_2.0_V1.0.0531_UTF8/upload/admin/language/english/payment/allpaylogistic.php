<?php
// Heading
$_['heading_title']			= 'allPay 超商取貨付款';

// Text
$_['text_allpaylogistic'] 	= '<a href="https://www.allpay.com.tw/" target="_blank"><img src="view/image/payment/allpaylogistic.png" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_success']			= '成功：您已成功修改 allPay 超商取貨付款設定!';
$_['text_edit']				= 'allPay 超商取貨付款';
$_['text_payment']			= 'Payment';
$_['entry_order_status']	= '訂單狀態';


?>