<?php 
if (isset($this->session->data['shipping_method']['code']) && strpos($this->session->data['shipping_method']['code'],"allpaylogistic.") !== false) {
	$order_data['shipping_address_1'] = $this->session->data["shipping_methods"]["allpaylogistic"]['CVSStoreID'];

	$order_data['shipping_address_2'] = $this->session->data["shipping_methods"]["allpaylogistic"]['CVSStoreName']." ".$this->session->data["shipping_methods"]["allpaylogistic"]['CVSAddress'];
	if (strpos($this->session->data['shipping_method']['code'],"allpaylogistic.unimart") !== false) {
		$order_data['shipping_address_2'] = "統一超商" . $order_data['shipping_address_2'];
	}
	if (!empty($this->session->data["shipping_methods"]["allpaylogistic"]['CVSTelephone'])) {
		$order_data['shipping_address_2'] .= "(".$this->session->data["shipping_methods"]["allpaylogistic"]['CVSTelephone'].")";
	}
	
	$order_data['shipping_country'] = 'Taiwan';
	$order_data['shipping_country_id'] = '206';
	$order_data['shipping_zone'] = '';
}
?>