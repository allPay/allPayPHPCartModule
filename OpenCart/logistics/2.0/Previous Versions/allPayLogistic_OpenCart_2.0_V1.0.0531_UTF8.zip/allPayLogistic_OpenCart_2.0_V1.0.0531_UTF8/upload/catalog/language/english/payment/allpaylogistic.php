<?php
// Text
$_['text_title']       = 'allPay 超商取貨付款';
?>