<?php if(isset($shipping_methods['allpaylogistic'])){ ?>
<?php 
$quote=$shipping_methods['allpaylogistic']['quote']; 
//取出額外資訊
if (isset($quote['unimart']['Extra'])) {
	$extra = $quote['unimart']['Extra'];
} elseif (isset($quote['unimart_collection']['Extra'])) {
	$extra = $quote['unimart_collection']['Extra'];
} elseif (isset($quote['fami']['Extra'])) {
	$extra = $quote['fami']['Extra'];
} elseif (isset($quote['fami_collection']['Extra'])) {
	$extra = $quote['fami_collection']['Extra'];
}
?>
<div class="allpaylogistic-control-area" style="display:none;">
	<div id="allpaylogistic-store-info">
		<div class="form-horizontal store-info">
			<h4><?php echo $extra['text_store_info'];?></h4>
			<div class=" form-group">
				<div class="col-sm-2"><?php echo $extra['text_store_name']?></div>
				<div class="col-sm-10 allpaylogistic_stname"></div>
			</div>
			<div class=" form-group">
				<div class="col-sm-2"><?php echo $extra['text_store_address']?></div>
				<div class="col-sm-10 allpaylogistic_staddr"></div>
			</div>
			<div class=" form-group">
				<div class="col-sm-2"><?php echo $extra['text_store_tel']?></div>
				<div class="col-sm-10 allpaylogistic_sttel"></div>
			</div>
		</div>
		<p class="allpaylogistic-warning bg-danger" style="padding:5px;"><?php echo $extra['error_no_storeinfo']; ?></p>
		<input type="hidden" class="checkselectallpaylogistic" value="nonselected" />
		<input type="button" id="allpaylogistic" class="btn btn-primary btn-xs" value="<?php echo $extra['text_choice']; ?>" onClick="javascript:show_cvs_map()"/>
	</div>
</div>

<script type="text/javascript">
<!--
var show_cvs_url = 'index.php?route=shipping/allpaylogistic/show_cvs_map&shipping_method=';
var iframe_link = '';
function show_cvs_map() {
	window.open(iframe_link,'CVS map',config='width=1024,height=600,status=no,scrollbars=yes,toolbar=no,location=no,menubar=no');
}
function set_store_info(CVSStoreID,CVSStoreName,CVSAddress,CVSTelephone) {
	$('.allpaylogistic_stname').html(CVSStoreName);
	$('.allpaylogistic_staddr').html(CVSAddress);
	$('.allpaylogistic_sttel').html(CVSTelephone);
	$('.store-info').show();
	$('.allpaylogistic-warning').hide();
	$('.checkselectallpaylogistic').prop('value','selected');
}
$(document).ready(function(){
	$('input[name=shipping_method]').change(function() {
		$('.checkselectallpaylogistic').prop('value','nonselected');
		$('.allpaylogistic_stname').html('');
		$('.allpaylogistic_staddr').html('');
		$('.allpaylogistic_sttel').html('');
		if ($('input[name=shipping_method]:checked').val().indexOf('allpaylogistic.') == 0){
			$('#allpaylogistic-store-info').fadeIn();
			iframe_link = show_cvs_url + $('input[name=shipping_method]:checked').val();
		} else{
			$('#allpaylogistic-store-info').fadeOut();
		}
	});
	$( "input[name$='shipping_method']" ).each(function( index ) {
		if($( this ).val() == 'allpaylogistic.<?php echo $extra['last_allpaylogistic_shipping_code'];?>'){
			var htnlCode=$('.allpaylogistic-control-area').html();
			$( this ).parent().after(htnlCode);
			$('.allpaylogistic-control-area').remove();
		}
	});
	$('.allpaylogistic-warning').hide();
	$('#allpaylogistic-store-info').hide();
	if ($('input[name=shipping_method]:checked').val().indexOf('allpaylogistic.') == 0){
		$('#allpaylogistic-store-info').show();
		iframe_link = show_cvs_url + $('input[name=shipping_method]:checked').val();
	}else{
		$('.allpaylogistic-warning').hide();
		$('#allpaylogistic-store-info').hide();
	}
	$('#button-shipping-method').click(function() {
		$('.allpaylogistic-warning').hide();
		if($('.checkselectallpaylogistic').val() != "selected" && $('input[name=shipping_method]:checked').val().indexOf('allpaylogistic.') == 0){
			$('.allpaylogistic-warning').show();
			return false;
		}
	});
 });
//-->
</script>
<?php } ?>
