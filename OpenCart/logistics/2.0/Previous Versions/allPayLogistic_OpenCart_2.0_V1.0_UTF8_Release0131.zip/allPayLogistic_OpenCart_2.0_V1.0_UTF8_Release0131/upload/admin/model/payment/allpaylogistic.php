<?php
class ModelPaymentallpaylogistic extends Model {
	public function install() {
		
	}
	
	public function uninstall() {
		
	}
	
	public function checkshipment($status) {
		
	}
?>