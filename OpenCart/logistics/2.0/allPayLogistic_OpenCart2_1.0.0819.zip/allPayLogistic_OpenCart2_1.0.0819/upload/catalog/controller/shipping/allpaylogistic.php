<?php
class ControllerShippingallPayLogistic extends Controller {
	protected function index() {
	}
	
	public function show_cvs_map() {
		include_once("admin/controller/shipping/allpaylogistic.inc.php");
		$sFieldName = 'code';
		if (!column_exists($this->db, DB_PREFIX."setting", 'code')) {
			$sFieldName = 'group';
		} 
		$get_allpaylogistic_setting_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `" . $sFieldName . "` = 'allpaylogistic'");
		$allpaylogisticSetting=array();
		foreach($get_allpaylogistic_setting_query->rows as $value){
			$allpaylogisticSetting[$value["key"]]=$value["value"];
		}
		
		include_once("admin/controller/shipping/AllPay.Logistics.Integration.php");
		
		if ($allpaylogisticSetting['allpaylogistic_type'] == 'C2C') {
			$al_subtype = (strpos($this->request->get['shipping_method'],'fami')) ? LogisticsSubType::FAMILY_C2C : LogisticsSubType::UNIMART_C2C;
		} else {
			$al_subtype = (strpos($this->request->get['shipping_method'],'fami')) ? LogisticsSubType::FAMILY : LogisticsSubType::UNIMART;
		}
		if (!isset($al_subtype)) {
			exit;
		}
		$al_iscollection = (strpos($this->request->get['shipping_method'],'_collection')) ? IsCollection::YES : IsCollection::NO;
		$al_srvreply = (($_SERVER['HTTPS']) ? "https" : "http") . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '/index.php?route=shipping/allpaylogistic/set_store_info';
		
		try {
			$AL = new AllpayLogistics();
			$AL->Send = array(
				'MerchantID' => $allpaylogisticSetting['allpaylogistic_mid'],
				'MerchantTradeNo' => 'no' . date('YmdHis'),
				'LogisticsSubType' => $al_subtype,
				'IsCollection' => $al_iscollection,
				'ServerReplyURL' => $al_srvreply,
				'ExtraData' => '',
				'Device' => Device::PC
			);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
		$html = $AL->CvsMap('');
		echo $html;
	}
	
	public function show_cvs_map_by_order() {
		$order_id = $this->request->get['order_id'];
		
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/order/info', 'order_id=' . $order_id, 'SSL');

			$this->response->redirect($this->url->link('account/login', '', 'SSL'));
		}
		$this->load->model('account/order');

		$aorder_info = $this->model_account_order->getOrder($order_id);
		
		if ($aorder_info) {
			include_once("admin/controller/shipping/AllPay.Logistics.Integration.php");
			include_once("admin/controller/shipping/allpaylogistic.inc.php");
			$sServerReply = (($_SERVER['HTTPS']) ? "https" : "http") . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '/index.php?route=shipping/allpaylogistic/set_store_info_by_order';
			_show_cvs_map_by_order($this->db,$order_id,$sServerReply);
		} else {
			echo "訂單編號不存在";
			exit;
		}
	}
	
	public function set_store_info() {
		if($this->request->post['CVSStoreID']){
			$this->session->data["shipping_methods"]["allpaylogistic"]['CVSStoreID'] = $this->request->post['CVSStoreID'];
			$this->session->data["shipping_methods"]["allpaylogistic"]['CVSStoreName'] = $this->request->post['CVSStoreName'];
			$this->session->data["shipping_methods"]["allpaylogistic"]['CVSAddress'] = $this->request->post['CVSAddress'];
			$this->session->data["shipping_methods"]["allpaylogistic"]['CVSTelephone'] = (isset($this->request->post['CVSTelephone'])) ? $this->request->post['CVSTelephone'] : '';
			
			header("Content-Type:text/html; charset=utf-8");
			echo "<script type='text/javascript'>";
			echo "window.opener.set_store_info('" . $this->request->post['CVSStoreID'] . "','" . $this->request->post['CVSStoreName'] . "','". $this->request->post['CVSAddress'] ."','" . $this->request->post['CVSTelephone'] . "');";
			echo "window.close();";
			echo "</script>";
		}
	}
	
	public function set_store_info_by_order() {
		$order_id = $this->request->post['ExtraData'];
		
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/order/info', 'order_id=' . $order_id, 'SSL');

			$this->response->redirect($this->url->link('account/login', '', 'SSL'));
		}
		$this->load->model('account/order');

		$aorder_info = $this->model_account_order->getOrder($order_id);
		if (!$aorder_info) {
			echo "訂單編號不存在";
			exit;
		}
		
		if($this->request->post['CVSStoreID']){
			include_once("admin/controller/shipping/allpaylogistic.inc.php");
			_set_store_info_by_order($this->db,$this->request->post);
		} else {
			echo "門市資訊錯誤";
			exit;
		}
	}
	
	public function response() {
		include_once("admin/controller/shipping/AllPay.Logistics.Integration.php");
		include_once("admin/controller/shipping/allpaylogistic.inc.php");
		$sFieldName = 'code';
		if (!column_exists($this->db, DB_PREFIX."setting", 'code')) {
			$sFieldName = 'group';
		} 
		$get_allpaylogistic_setting_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `" . $sFieldName . "` = 'allpaylogistic'");
		$allpaylogisticSetting=array();
		foreach($get_allpaylogistic_setting_query->rows as $value){
			$allpaylogisticSetting[$value["key"]]=$value["value"];
		}
		try {
			$AL = new AllpayLogistics();
			$AL->HashKey = $allpaylogisticSetting['allpaylogistic_hashkey'];
			$AL->HashIV = $allpaylogisticSetting['allpaylogistic_hashiv'];
			$AL->CheckOutFeedback($this->request->post);
			$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order` WHERE order_id = '" . (int)$this->request->post['MerchantTradeNo'] . "'" );
            $aOrder_Info_Tmp = $query->rows[0] ;
			$sMsg = "歐付寶廠商管理後台物流訊息:<br>" . print_r($this->request->post, true);
			if ($this->request->post['RtnCode'] == '2067' || $this->request->post['RtnCode'] == '3022') {
				$aOrder_Info_Tmp['order_status_id'] = 5;
			}
			$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$this->request->post['MerchantTradeNo'] . "', order_status_id = '" . (int)$aOrder_Info_Tmp['order_status_id'] . "', notify = '0', comment = '" . $this->db->escape($sMsg) . "', date_added = NOW()");
			echo '1|OK';
		} catch(Exception $e) {
			echo '0|' . $e->getMessage();
		}
	}
	
	public function LogisticsC2CReply() {
		include_once("admin/controller/shipping/AllPay.Logistics.Integration.php");
		$get_allpaylogistic_setting_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `code` = 'allpaylogistic'");
		$allpaylogisticSetting=array();
		foreach($get_allpaylogistic_setting_query->rows as $value){
			$allpaylogisticSetting[$value["key"]]=$value["value"];
		}
		try {
			$AL = new AllpayLogistics();
			$AL->HashKey = $allpaylogisticSetting['allpaylogistic_hashkey'];
			$AL->HashIV = $allpaylogisticSetting['allpaylogistic_hashiv'];
			$AL->CheckOutFeedback($this->request->post);
			$query = $this->db->query("SELECT * FROM `allpaylogistic_info` WHERE AllPayLogisticsID =".$this->db->escape($this->request->post['AllPayLogisticsID']));
			if ($query->num_rows) {
				$aAL_info = $query->rows[0];
				$this->db->query("UPDATE " . DB_PREFIX . "order SET order_status_id = 1 WHERE order_id = ".(int)$aAL_info['order_id']);
				$sMsg = "歐付寶廠商管理後台更新門市通知:<br>" . print_r($this->request->post, true);
				$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$aAL_info['order_id'] . "', order_status_id = '1', notify = '0', comment = '" . $this->db->escape($sMsg) . "', date_added = NOW()");
				echo '1|OK';
			} else {
				echo '0|AllPayLogisticsID not found';
			}
		} catch(Exception $e) {
			echo '0|' . $e->getMessage();
		}
	}
}
?>