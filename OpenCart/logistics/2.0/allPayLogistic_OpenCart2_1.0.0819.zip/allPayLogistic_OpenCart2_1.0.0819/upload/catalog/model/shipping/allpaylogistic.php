<?php
class ModelShippingallpaylogistic extends Model {
	function getQuote($address) {
		$this->load->language('shipping/allpaylogistic');
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('allpaylogistic_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
	
		if (!$this->config->get('allpaylogistic_geo_zone_id')) {
			$status = true;
		} elseif ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}

		include_once("admin/controller/shipping/allpaylogistic.inc.php");
		$sFieldName = 'code';
		if (!column_exists($this->db, DB_PREFIX."setting", 'code')) {
			$sFieldName = 'group';
		} 
		$get_allpaylogistic_setting_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `" . $sFieldName . "` = 'allpaylogistic'");
		$allpaylogisticSetting=array();
		foreach($get_allpaylogistic_setting_query->rows as $value){
			$allpaylogisticSetting[$value["key"]]=$value["value"];
		}
		//超商取貨金額範圍
		if ($this->cart->getSubTotal()<$allpaylogisticSetting['allpaylogistic_min_amount'] || $this->cart->getSubTotal()>$allpaylogisticSetting['allpaylogistic_max_amount'] ) {
			$status = false;
		} 
		//免運費金額
		$isFreeShipping = false;
		if ($this->cart->getSubTotal()>=$allpaylogisticSetting['allpaylogistic_free_shipping_amount']) {
			$isFreeShipping = true;
		}
		
		if ($status) {
			//if($allpaylogisticSetting["allpaylogistic_status"] == "1"){
			//}
			
			// shipping_method.tpl 所需的額外資訊
			$Extra = array();
			// 定義 allpaylogistic-control-area 的位置
			$Extra['last_allpaylogistic_shipping_code'] = '';
			// 語系
			$Extra['text_choice'] = $this->language->get('text_choice');
			$Extra['text_rechoice'] = $this->language->get('text_rechoice');
			$Extra['text_store_name'] = $this->language->get('text_store_name');
			$Extra['text_store_address'] = $this->language->get('text_store_address');
			$Extra['text_store_tel'] = $this->language->get('text_store_tel');
			$Extra['text_store_info'] = $this->language->get('text_store_info');
			$Extra['error_no_storeinfo'] = $this->language->get('error_no_storeinfo');

			if ($allpaylogisticSetting['allpaylogistic_unimart_status']) {
				$shipping_cost = ($isFreeShipping) ? 0 : $allpaylogisticSetting['allpaylogistic_unimart_fee'];
				$quote_text = (strpos(VERSION, '2.2.') !== false) ? $this->currency->format($shipping_cost, $this->session->data['currency']) : $this->currency->format($shipping_cost);
				$quote_data['unimart'] = array(
						'code'         => 'allpaylogistic.unimart',
						'title'        => $this->language->get('text_unimart'),
						'cost'         => $shipping_cost,
						'tax_class_id' => 0,
						'text'         => $quote_text,
				);
				$Extra['last_allpaylogistic_shipping_code'] = 'unimart';
			}
			if ($allpaylogisticSetting['allpaylogistic_unimart_collection_status']) {
				$shipping_cost = ($isFreeShipping) ? 0 : $allpaylogisticSetting['allpaylogistic_unimart_collection_fee'];
				$quote_text = (strpos(VERSION, '2.2.') !== false) ? $this->currency->format($shipping_cost, $this->session->data['currency']) : $this->currency->format($shipping_cost);
				$quote_data['unimart_collection'] = array(
						'code'         => 'allpaylogistic.unimart_collection',
						'title'        => $this->language->get('text_unimart_collection'),
						'cost'         => $shipping_cost,
						'tax_class_id' => 0,
						'text'         => $quote_text,
				);
				$Extra['last_allpaylogistic_shipping_code'] = 'unimart_collection';
			}
			
			if ($allpaylogisticSetting['allpaylogistic_fami_status']) {
				$shipping_cost = ($isFreeShipping) ? 0 : $allpaylogisticSetting['allpaylogistic_fami_fee'];
				$quote_text = (strpos(VERSION, '2.2.') !== false) ? $this->currency->format($shipping_cost, $this->session->data['currency']) : $this->currency->format($shipping_cost);
				$quote_data['fami'] = array(
						'code'         => 'allpaylogistic.fami',
						'title'        => $this->language->get('text_fami'),
						'cost'         => $shipping_cost,
						'tax_class_id' => 0,
						'text'         => $quote_text,
				);
				$Extra['last_allpaylogistic_shipping_code'] = 'fami';
			}
			
			if ($allpaylogisticSetting['allpaylogistic_fami_collection_status']) {
				$shipping_cost = ($isFreeShipping) ? 0 : $allpaylogisticSetting['allpaylogistic_fami_collection_fee'];
				$quote_text = (strpos(VERSION, '2.2.') !== false) ? $this->currency->format($shipping_cost, $this->session->data['currency']) : $this->currency->format($shipping_cost);
				$quote_data['fami_collection'] = array(
						'code'         => 'allpaylogistic.fami_collection',
						'title'        => $this->language->get('text_fami_collection'),
						'cost'         => $shipping_cost,
						'tax_class_id' => 0,
						'text'         => $quote_text,
				);
				$Extra['last_allpaylogistic_shipping_code'] = 'fami_collection';
			}

			unset($quote_text);
			
			if (!isset($quote_data)) {
				$status = false;
			} else {
				$quote_data[$Extra['last_allpaylogistic_shipping_code']]['Extra'] = $Extra;
			}
		}
		
		$method_data = array();
		if ($status) {
			$method_data = array(
					'code'       => 'allpaylogistic',
					'title'      => $this->language->get('heading_title'),
					'quote'      => $quote_data,
					'sort_order' => $this->config->get('allpaylogistic_sort_order'),
					'extra' => $Extra,
					'error'      => false
			);
		}
			
		return $method_data;
	}
}
