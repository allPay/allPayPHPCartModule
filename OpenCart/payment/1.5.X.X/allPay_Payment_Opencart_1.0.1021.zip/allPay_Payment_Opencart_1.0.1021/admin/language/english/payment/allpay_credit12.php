<?php
// Heading
$_['heading_title']      = 'AllPay - Credit Card(12 Installments)';
