<?php
// Heading
$_['heading_title']      = 'AllPay - Credit Card(18 Installments)';
