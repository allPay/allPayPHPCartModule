<?php
// Heading
$_['heading_title']      = 'Allpay - Top Up Used';
