<?php
// Heading
$_['heading_title']      = 'AllPay - Credit Card(30 Installments)';
