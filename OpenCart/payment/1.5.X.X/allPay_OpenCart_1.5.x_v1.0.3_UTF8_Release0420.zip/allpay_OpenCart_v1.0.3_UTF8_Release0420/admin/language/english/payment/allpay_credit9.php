<?php
// Heading
$_['heading_title']      = 'AllPay - Credit Card(9 Installments)';
