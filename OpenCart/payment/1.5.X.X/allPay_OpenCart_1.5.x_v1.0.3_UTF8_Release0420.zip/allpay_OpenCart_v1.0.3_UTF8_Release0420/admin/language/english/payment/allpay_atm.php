<?php
// Heading
$_['heading_title']      = 'AllPay - ATM';
