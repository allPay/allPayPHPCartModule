<?php
// Heading
$_['heading_title']      = 'AllPay - Credit Card(6 Installments)';
