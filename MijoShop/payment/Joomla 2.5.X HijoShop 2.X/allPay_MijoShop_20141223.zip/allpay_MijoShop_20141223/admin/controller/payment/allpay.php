<?php
	/**
	 * @package		AllPay for Joomla Mijoshop
	 * @version		1.0.0
	 * @author		Shawn Chang
	 * @copyright	Copyright 2013-2014 AllPay Financial Information Service Co., Ltd. All rights reserved.
	 */

	class ControllerPaymentAllpay extends Controller
	{
		const PAYMENT_NAME = 'allpay';
		const VAR_PREFIX = 'allpay_';
		
		/**
		 * @method 付款方式設定頁面
		 */
		public function index()
		{
      # 取得語言資訊
			$this->load->model('localisation/language');
			$this->load->language('payment/' . self::PAYMENT_NAME);
			
			# 取得地理位置資訊
			$this->load->model('localisation/geo_zone');
			$this->data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
			
			# 取得訂單資訊
			$this->load->model('localisation/order_status');
      $this->data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

      $token = $this->session->data['token'];

      # 載入相關 Model
      $this->load->model('setting/setting');
			if (($this->request->server['REQUEST_METHOD'] == 'POST') and $this->validate())
			{
				# 更新模組設定
				$this->model_setting_setting->editSetting(self::PAYMENT_NAME, $this->request->post);
				
				$this->session->data['success'] = $this->language->get('text_success');
				
				$this->redirect($this->url->link('extension/payment', 'token=' . $token, 'SSL'));
			}
			
			# header 設定
			$this->data['heading_title'] = $this->language->get('heading_title');			
			
			# 欄位說明設定
			$this->data['des_description'] = $this->language->get('des_description');
			$this->data['des_test_mode'] = $this->language->get('des_test_mode');
			$this->data['des_merchant_id'] = $this->language->get('des_merchant_id');
			$this->data['des_hash_key'] = $this->language->get('des_hash_key');
			$this->data['des_hash_iv'] = $this->language->get('des_hash_iv');
			$this->data['des_order_status'] = $this->language->get('des_order_status');
			$this->data['des_paid_status'] = $this->language->get('des_paid_status');
			$this->data['des_unpaid_status'] = $this->language->get('des_unpaid_status');
			$this->data['des_geo_zone'] = $this->language->get('des_geo_zone');
			$this->data['des_payment_status'] = $this->language->get('des_payment_status');
			$this->data['des_sort_order'] = $this->language->get('des_sort_order');
			
			# 變數前置字元設定
			$this->data['var_prefix'] = self::VAR_PREFIX;
			
			# 欄位內容設定
			$this->data['text_enabled'] = $this->language->get('text_enabled');
			$this->data['text_disabled'] = $this->language->get('text_disabled');
			$this->data['text_all_zones'] = $this->language->get('text_all_zones');
					
			# 按鈕內容設定
			$this->data['button_save'] = $this->language->get('button_save');
			$this->data['button_cancel'] = $this->language->get('button_cancel');
			
			# 錯誤訊息設定
			$error_list = array('permission', 'merchant_id', 'hash_key', 'hash_iv');
			foreach($error_list as $tmp_piece)
			{
				$tmp_name = 'error_' . $tmp_piece;
				if (isset($this->error[$tmp_name]))
				{
					$this->data[$tmp_name] = $this->error[$tmp_name];
				}
			}
			unset($error_list);
			unset($tmp_name);
			
			# 設定網頁路徑
			$this->data['breadcrumbs'] = array(
				array(
					'text' => $this->language->get('text_home')
					, 'href' => $this->url->link('common/home', 'token=' . $token, 'SSL')
					, 'separator' => false
				)
				, array(
					'text' => $this->language->get('text_payment')
					, 'href' => $this->url->link('extension/payment', 'token=' . $token, 'SSL')
					, 'separator' => ' :: '
				)
				, array(
					'text' => $this->language->get('heading_title')
					, 'href' => $this->url->link('payment/' . self::PAYMENT_NAME, 'token=' . $token, 'SSL')
					, 'separator' => ' :: '
				)	
			);
			
			# 設定按下按鍵導向頁面
			$this->data['action'] = $this->url->link('payment/' . self::PAYMENT_NAME, 'token=' . $token, 'SSL');
			$this->data['cancel'] = $this->url->link('extension/payment', 'token=' . $token, 'SSL');
			unset($token);
			
			# 取得傳入POST參數
			$languages = $this->model_localisation_language->getLanguages();
			$this->data['languages'] = $languages;
			foreach ($languages as $language) 
			{
				$tmp_name = self::VAR_PREFIX . 'description_' . $language['language_id'];
				if (isset($this->request->post[$tmp_name]))
				{
					$tmp_val = $this->request->post[$tmp_name];
				}
				else
				{
					$tmp_val = $this->config->get($tmp_name);
				}
				$this->data[$tmp_name] = $tmp_val;
			}
			unset($languages);
			unset($tmp_name);
			unset($tmp_val);
			
			$tmp_var_list = array(
					'test_mode', 'merchant_id', 'hash_key'
					, 'hash_iv', 'order_status_id', 'paid_status_id'
					, 'unpaid_status_id', 'geo_zone_id', 'status'
					, 'sort_order'
			);
			foreach ($tmp_var_list as $tmp_piece)
			{
				$tmp_name = self::VAR_PREFIX . $tmp_piece;
				if (isset($this->request->post[$tmp_name]))
				{
					$tmp_val = $this->request->post[$tmp_name];
				}
				else
				{
					$tmp_val = $this->config->get($tmp_name);
				}
				$this->data[$tmp_name] = $tmp_val;
			}
			unset($tmp_var_list);
			unset($tmp_val);
			
			# 設定顯示頁面
			$this->template = 'payment/' . self::PAYMENT_NAME . '.tpl';
			$this->children = array(
				'common/header',
				'common/footer',
			);
			
			# 顯示頁面
			$this->response->setOutput($this->render());
		}
		
		/**
		 * @method 權限與參數檢查
		 * @return boolean 檢查結果
		 */
		private function validate()
		{
			# 權限檢查
			if (!$this->user->hasPermission('modify', 'payment/' . self::PAYMENT_NAME))
			{
				$this->error['error_permission'] = $this->language->get('error_permission');
			}
			
			# 必填欄位檢查
			$key_list = array('merchant_id', 'hash_key', 'hash_iv');
			foreach ($key_list as $tmp_name)
			{
				if (!$this->request->post[self::VAR_PREFIX . $tmp_name])
				{
					$tmp_error_name = 'error_' . $tmp_name;
					$this->error[$tmp_error_name] = $this->language->get($tmp_error_name);
				}
			}
			
			return (empty($this->error) ? true : false);
		}
	}
