<?php
	/**
	 * @package		AllPay for Joomla Mijoshop
	 * @version		1.0.0
	 * @author		Shawn Chang
	 * @copyright	Copyright 2013-2014 AllPay Financial Information Service Co., Ltd. All rights reserved.
	 */
	 
	# Permission Check
	defined('_JEXEC') or die('Restricted access');
	
	# Head Page Config
	$_['heading_title'] = 'AllPay';
	
	# Display Text Config
	$_['text_payment'] = 'Payment';
	$_['text_success'] = 'Success';

	# Entry Description Config
	$_['des_description'] = 'Payment Description:';
	$_['des_test_mode'] = 'Test Mode:';
	$_['des_merchant_id'] = 'Merchant ID:';
	$_['des_hash_key'] = 'Hash Key:';
	$_['des_hash_iv'] = 'Hash IV:';
	$_['des_order_status'] = 'Order Status:';
	$_['des_paid_status'] = 'Paid Status:';
	$_['des_unpaid_status'] = 'Unpaid Status:';
	$_['des_geo_zone'] = 'Geo Zone:';
	$_['des_payment_status'] = 'Payment Status:';
	$_['des_sort_order'] = 'Sort Order:';

	# Error Message Config
	$_['error_permission'] = 'You are not permission to modify settings';
	$_['error_merchant_id'] = 'Please input merchant id';
	$_['error_hash_key'] = 'Please input hash key';
	$_['error_hash_iv'] = 'Please input hash iv';