<?php
	/**
	 * @package		AllPay for Joomla Mijoshop
	 * @version		1.0.0
	 * @author		Shawn Chang
	 * @copyright	Copyright 2013-2014 AllPay Financial Information Service Co., Ltd. All rights reserved.
	 */
	 
	# Permission Check
	defined('_JEXEC') or die('Restricted access');
	
	# Head Page Config
	$_['heading_title'] = 'AllPay';
	
	# Display Text Config
	$_['text_payment'] = '付款方式';
	$_['text_success'] = '完成';

	# Entry Description Config
	$_['des_description'] = '付款方式說明:';
	$_['des_test_mode'] = '測試模式:';
	$_['des_merchant_id'] = '商店代號:';
	$_['des_hash_key'] = '金鑰:';
	$_['des_hash_iv'] = '向量:';
	$_['des_order_status'] = '訂單成立狀態:';
	$_['des_paid_status'] = '付款成功狀態:';
	$_['des_unpaid_status'] = '付款失敗狀態:';
	$_['des_geo_zone'] = '地理位置:';
	$_['des_payment_status'] = '付款方式啟用狀態:';
	$_['des_sort_order'] = '排列順序:';

	# Error Message Config
	$_['error_permission'] = '你沒有權限修改這項設定';
	$_['error_merchant_id'] = '請輸入商店代號';
	$_['error_hash_key'] = '請輸金鑰';
	$_['error_hash_iv'] = '請輸入向量';