<?php
	# AllPay Payment Name
	$_['text_title'] = 'AllPay';
	
	$_['paid_failed_comment'] = '付款失敗';
	$_['paid_success_comment'] = '付款成功';
	
	$_['payment_alias'] = array(
		'Credit' => '信用卡'
		, 'WebATM' => '網路 ATM'
		, 'ATM' => '自動櫃員機'
		, 'CVS' => '超商代碼'
		, 'BARCODE' => '超商條碼'
		, 'Alipay' => '海外支付-支付寶'
		, 'Tenpay' => '海外支付-財付通'
		, 'TopUpUsed' => '儲值消費'
	);
?>