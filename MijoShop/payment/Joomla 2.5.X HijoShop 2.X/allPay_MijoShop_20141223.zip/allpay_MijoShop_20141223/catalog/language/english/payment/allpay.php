<?php
	# AllPay Payment Name
	$_['text_title'] = 'AllPay';
	
	$_['paid_failed_comment'] = 'Paid Failed';
	$_['paid_success_comment'] = 'Paid Success';
	
	$_['payment_alias'] = array(
		'Credit' => 'Credit'
		, 'WebATM' => 'Web ATM'
		, 'ATM' => 'ATM'
		, 'CVS' => 'Convenient Store'
		, 'BARCODE' => 'BARCODE'
		, 'Alipay' => 'Alipay'
		, 'Tenpay' => 'Tenpay'
		, 'TopUpUsed' => 'Top Up Used'
	);
?>