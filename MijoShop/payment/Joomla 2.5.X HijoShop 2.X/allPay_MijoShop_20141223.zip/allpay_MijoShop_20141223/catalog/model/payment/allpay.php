<?php 
	/**
	 * @package		AllPay for Joomla Mijoshop
	 * @version		1.0.0
	 * @author		Shawn Chang
	 * @copyright	Copyright 2013-2014 AllPay Financial Information Service Co., Ltd. All rights reserved.
	 */
	class ModelPaymentAllPay extends Model
	{
		/**
		 * @method 取得付款方式相關設定
		 * @array  地址相關資訊
		 * @return 設定資料
		 */
		public function getMethod($address)
		{
			define('PAYMENT_NAME', 'AllPay');
			$this->load->language('payment/' . PAYMENT_NAME);
			
			$sql = 'SELECT * from ' . DB_PREFIX . 'zone_to_geo_zone';
			$sql .= ' WHERE `geo_zone_id` = "' . (int)$this->config->get(PAYMENT_NAME . '_geo_zone_id') . '"';
			$sql .= ' AND `country_id` = "' . (int)$address['country_id'] . '"';
			$sql .= ' AND (`zone_id` = "' . (int)$address['zone_id'] . '" OR `zone_id` = "0")';
			
			$query = $this->db->query($sql);
			
			$status = (!$this->config->get('alertpay_geo_zone_id') || $query->num_rows) ? true : false;
				
			$method_data = array();
				
			if ($status) {
				$method_data = array(
						'code'       => 'allpay',
						'title'      => $this->language->get('text_title'),
						'sort_order' => $this->config->get('AllPay_sort_order')
				);
			}
			 
			return $method_data;
		}
	}
?>