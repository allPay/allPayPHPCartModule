<?php
	/**
	 * @package		AllPay for Joomla Mijoshop
	 * @version		1.0.0
	 * @author		Shawn Chang
	 * @copyright	Copyright 2013-2014 AllPay Financial Information Service Co., Ltd. All rights reserved.
	 */
class ControllerPaymentAllPay extends Controller
{
	const PAYMENT_NAME = 'allpay';
	const VAR_PREFIX = 'allpay_';
	
	/**
	 * @method 設定付款方式表單頁面
	 */
	public function index()
	{
		$this->data['button_confirm'] = $this->language->get('button_confirm');
		
		$isTestMode = $this->config->get(self::VAR_PREFIX . 'test_mode');
		
		try
		{
			# 取得結帳資訊
			$this->load->model('checkout/order');
			$checkout_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
			
			# 設定連環境相關參數
			if (!$isTestMode)
			{
				$service_url = 'https://payment.allpay.com.tw/Cashier/AioCheckOut';
				$order_id = $checkout_info['order_id'];
			}
			else
			{
				$service_url = 'http://payment-stage.allpay.com.tw/Cashier/AioCheckOut';
				$order_id = date('is') . $checkout_info['order_id'];
			}
			
			# 設定基本參數
			$this->_loadAIO();
			$aio = new AllInOne();
			$aio->ServiceURL = $service_url;
			$aio->MerchantID = $this->config->get(self::VAR_PREFIX . 'merchant_id');
			$aio->HashKey = $this->config->get(self::VAR_PREFIX . 'hash_key');
			$aio->HashIV = $this->config->get(self::VAR_PREFIX . 'hash_iv');
			$aio->Send['ReturnURL'] = $this->url->link('payment/' . self::PAYMENT_NAME . '/response', '', 'SSL');
			$aio->Send['ClientBackURL'] = $this->url->link('common/home', '', 'SSL');
			$aio->Send['MerchantTradeNo'] = $order_id;
			$aio->Send['MerchantTradeDate'] = date('Y/m/d H:i:s');
			unset($service_url);
			unset($order_id);
			
			# 取得訂單資訊
			$order_info = $this->cart->getProducts();
			
			# 設定訂單商品資訊
			foreach ($order_info as $tmp_product_info)
			{
				array_push($aio->Send['Items'], array(
					'Name' => $tmp_product_info['name']
					, 'Price' => $tmp_product_info['total']
					, 'Currency' => $checkout_info['currency_code']
					, 'Quantity' => $tmp_product_info['quantity']
				));
			}
			# 含稅含運總金額並轉換為整數
			$aio->Send['TotalAmount'] = (int) $checkout_info['total'];
			
			$aio->Send['TradeDesc'] = 'Allpay_Mijoshop_For_Joomla_Plugin';
			unset($order_info);
			unset($checkout_info);
	
			# 產生結帳 Form HTML
			$html_button = '<div class="buttons">';
      $html_button .= '<div class="right">';
      $html_button .= '<input id="PayButton" type="button" value="' . $this->language->get('button_confirm') . '" class="button" onclick="document.getElementById(\'__allpayForm\').submit();" />';
      $html_button .= '</div>';
    	$html_button .= '</div>';
    	$html_form = str_replace('<script type="text/javascript">document.getElementById("__allpayForm").submit();</script>', $html_button, $aio->CheckOutString(null));
			unset($aio);
    	unset($html_button);
    	
    	# 輸出結帳 HTML
    	$html_file = 'default/template/payment/allpay.tpl';
    	file_put_contents(DIR_TEMPLATE . $html_file, $html_form);
			unset($html_form);
    	$this->template = $html_file;
			unset($html_file);
			$this->render();
		}
		catch(Exception $e)
		{
			$html_error = '<div class="warning">';
			$html_error .= 'Warning: ' . $e->getMessage();
			$html_error .= '<img src="/joomla/components/com_mijoshop/opencart/catalog/view/theme/default/image/close.png" alt class="close">';
			$html_error .= '</div>';
			echo $html_error;
		}
	}
	
	/**
	 * @method 處理結帳結果
	 */
	public function response()
	{
		try
		{
			# 設定回應訊息
			$response_message = '1|OK';
		
			# 設定必要參數
			$this->_loadAIO();
			$aio = new AllInOne();
			$aio->MerchantID = $this->config->get(self::VAR_PREFIX . 'merchant_id');
			$aio->HashKey = $this->config->get(self::VAR_PREFIX . 'hash_key');
			$aio->HashIV = $this->config->get(self::VAR_PREFIX . 'hash_iv');
			
			# 取得付款結果
			$feedback = $aio->CheckOutFeedback();
			unset($aio);
			if(empty($feedback))
			{
				throw new Exception('Get Payment Center Feedback Failed.');
			}
			else
			{
				# 取得訂單資訊
				$order_id = $this->session->data['order_id'];
				$this->load->model('checkout/order');
				$order_info = $this->model_checkout_order->getOrder($order_id);
				if(empty($order_info))
				{
					throw new Exception('Order(' . $order_id . ') Not Found In MijoShop.');
				}
				else
				{
					# 核對訂單金額
					if ($feedback['TradeAmt'] != (int) $order_info['total'])
					{
						throw new Exception('Order(' . $order_id . ') Amount Are Not Identical.');
					}
					else
					{
						# 檢查付款狀態
						$return_code = $feedback['RtnCode'];
						$this->language->load('payment/allpay');
						if ($return_code != 1 and $return_code != 800)
						{
							$order_status_id = $this->config->get(self::VAR_PREFIX . 'unpaid_status_id');
							$order_comment = $this->language->get('paid_failed_comment');
							
							$response_message = '0|Order ' . $order_id . ' Exception.(' . $return_code . ': ' . $feedback['RtnMsg'] . ')';
						}
						else
						{
							$order_status_id = $this->config->get(self::VAR_PREFIX . 'paid_status_id');
							$order_comment = $this->language->get('paid_success_comment');
						}
						unset($return_code);
						
						$payment_alias = $this->language->get('payment_alias');
						
						# 更新訂單
						$this->model_checkout_order->confirm($order_id, $order_status_id, $payment_alias[$feedback['PaymentType']] . ' ' . $order_comment, true);
						unset($order_status_id);
						unset($order_comment);
						
						# 清空購物車
						$this->cart->clear();
					}
				}
				unset($order_info);
				unset($order_id);
			}
			unset($feedback);
		}
		catch(Exception $e)
		{
			$response_message = '0|' . $e->getMessage();
		}
		echo $response_message;
		exit;
	}
	
	/**
	 * @method 插入 AllInOne 模組
	 * @throw Exception
	 */
	private function _loadAIO()
	{
		$file_path = DIR_CATALOG . '/model/payment/AllPay.Payment.Integration.php';
		if (!class_exists('AllInOne'))
		{
			if (!file_exists($file_path))
			{
				throw new Exception('Required File ' . basename($file_path) . ' Not Found.');
			}
			else
			{
				require($file_path);
			}
		}
	}
	
}
?>