<?php
// Heading
$_['heading_title']      = '歐付寶 Allpay 財付通';
