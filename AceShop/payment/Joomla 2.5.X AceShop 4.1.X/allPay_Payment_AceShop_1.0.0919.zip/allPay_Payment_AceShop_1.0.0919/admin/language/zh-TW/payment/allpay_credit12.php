<?php
// Heading
$_['heading_title']      = '歐付寶 Allpay 信用卡(分12期)';
