<?php
// Heading
$_['heading_title']      = '歐付寶 Allpay 超商條碼';
